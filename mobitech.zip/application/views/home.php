<center>
<img src="http://mobitechdistributionsystem.com/system/images/logo.jpg" style="max-height:100%; max-width:100%; margin-top:20px;" />
    <div class="welcome-text">
		<h1>Welcome to</h1>		<br />
		<h2>MOBITECH DISTRIBUTION SYSTEM (MDS)</h2>    </div>
    <div class="description-text">Warehouse &amp; Logistic Division</div>
    </center>